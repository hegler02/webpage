@echo off
setlocal
"%SystemRoot%\System32\cscript.exe" //nologo //E:JScript "%~dp0iec-classroom.js"
set "setupResult=%errorlevel%"
pause
exit /b %setupResult%
